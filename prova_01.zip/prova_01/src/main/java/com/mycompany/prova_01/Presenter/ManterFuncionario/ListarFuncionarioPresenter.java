package com.mycompany.prova_01.Presenter.ManterFuncionario;

import com.mycompany.prova_01.Model.Funcionario;
import com.mycompany.prova_01.Presenter.AbstractPadrao;
import com.mycompany.prova_01.Presenter.CalcularBonus.ManterBonusPresenter;
import com.mycompany.prova_01.Presenter.ManterCargo.ManterCargoPresenter;
import com.mycompany.prova_01.View.ManterFuncionario.IfrmListarFuncionarioView;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.JInternalFrame;

public abstract class ListarFuncionarioPresenter extends AbstractPadrao {
    
    protected static IfrmListarFuncionarioView view;
    
    protected static ListarFuncionarioPresenter instancia;

    public ListarFuncionarioPresenter() {
    }
    
    public static ListarFuncionarioPresenter getInstancia() {
        if (instancia == null) {
            instancia = new ListarFuncionarioPresenter() {
                @Override
                public void botaoSalvarPressionado() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }

                @Override
                public void botaoEditarPressionado() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }

                @Override
                public void botaoExcluirPressionado() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }

                @Override
                public void botaoFecharPressionado() {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }
            };
        }
        return instancia;
    }
    
    @Override
    public void initView() {
        view = IfrmListarFuncionarioView.getInstancia();
        
    }
    
    public void setCampoValores(Map<String, String> valores) {
       // view.setCampoValores(valores);
    }
    
    public JInternalFrame getFrame() {
        view = IfrmListarFuncionarioView.getInstancia();
        return view;
    }
    
    public ArrayList<Funcionario> listaFuncionarios() {
        ArrayList<Funcionario> listaFuncionarios = new ArrayList<>();
        return listaFuncionarios;
    }
    // BOTÕES
    
    public abstract void botaoSalvarPressionado();
    
    public abstract void botaoEditarPressionado();

    public abstract void botaoExcluirPressionado();

    public abstract void botaoFecharPressionado();
    
    // ABRIR VIEW

    @Override
    public void abrirView(boolean b) {
        view.setVisible(b);
    }

}
