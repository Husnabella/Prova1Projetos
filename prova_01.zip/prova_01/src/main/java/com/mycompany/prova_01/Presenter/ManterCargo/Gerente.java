package com.mycompany.prova_01.Presenter.ManterCargo;

public class Gerente implements CargoPresenter {
    
    private final double salarioBase;
    
    private final String cargo;

    public Gerente() {
        this.salarioBase = 10000.00;
        this.cargo = "Gerente";
    }

    @Override
    public double getSalarioBase() {
        return salarioBase;
    }

    @Override
    public String getCargo() {
        return cargo;
    }
}
