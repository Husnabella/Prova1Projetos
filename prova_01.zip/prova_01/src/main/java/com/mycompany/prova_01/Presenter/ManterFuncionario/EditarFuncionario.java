package com.mycompany.prova_01.Presenter.ManterFuncionario;

import com.mycompany.prova_01.Model.Funcionario;
import com.mycompany.prova_01.Presenter.CalcularBonus.BonusPresenter;
import static com.mycompany.prova_01.Presenter.ManterFuncionario.ManterFuncionarioPresenter.view;
import com.mycompany.prova_01.Presenter.PopUpUtil;

public class EditarFuncionario extends ManterFuncionarioPresenter {
    
    private Funcionario funcionario;
    
    private static EditarFuncionario instancia;
    
    EditarFuncionario() {
        configuraCargo();
        configuraBonus();
        initView();
        setCamposEditableEditar(true);
        ajustarView(false, true, true, true);
    }
    
    public static EditarFuncionario getInstancia() {
        if (instancia == null) {
            instancia = new EditarFuncionario();
        }
        return instancia;
    }

    @Override
    public void botaoSalvarPressionado() {
        int id = funcionario.getIdFuncionario();
        for (Funcionario f : listaFuncionarios()) {
            if (id == f.getIdFuncionario()) {
                funcionario = f;
            } else {
                PopUpUtil.mostrarPopUpErro(null, "Funcionário Não Identificado");
            }
        }
        calculaBonus(view.getCampoBonus());
        funcionario.setNome(view.getCampoValores().get("nome"));
        funcionario.setCargo(view.getCampoCargo());
        funcionario.addBonus((BonusPresenter) novoBonus(view.getCampoBonus()));
        funcionario.setSalario(Double.parseDouble(view.getCampoValores().get("salario")));
        funcionario.setIdade(Integer.parseInt(view.getCampoValores().get("idade")));
        funcionario.setAdmissao(view.getCampoValores().get("admissao"));
        funcionario.setFaltas(Integer.parseInt(view.getCampoValores().get("faltas")));
        if(Integer.parseInt(view.getCampoValores().get("faltas")) < 0) {
            PopUpUtil.mostrarPopUpErro(null, "Insira um número de faltas positivo");
        }
        
        listaFuncionarios().add(funcionario);
    }

    @Override
    public void botaoExcluirPressionado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void botaoEditarPressionado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void botaoFecharPressionado() {
        view.dispose();
    }
}
