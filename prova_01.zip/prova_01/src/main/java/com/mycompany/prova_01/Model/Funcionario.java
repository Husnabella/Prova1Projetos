package com.mycompany.prova_01.Model;

import com.mycompany.prova_01.Presenter.CalcularBonus.BonusPresenter;
import com.mycompany.prova_01.Presenter.CalcularBonus.ManterBonusPresenter;
import java.util.ArrayList;

public class Funcionario {
    
    private int idFuncionario;
    private String nome;
    private double salario;
    private int idade;
    private String cargo;
    private int faltas;
    private String admissao;
    private final ArrayList<BonusPresenter> bonusRecebidos;

    public Funcionario(int idFuncionario, String nome, double salario, int idade, String cargo, String admissao) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.salario = salario;
        this.idade = idade;
        this.cargo = cargo;
        this.admissao = admissao;
        this.bonusRecebidos = new ArrayList<>();
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void addBonus(BonusPresenter bonus) {
        this.bonusRecebidos.add(bonus);
    }
    
    public ArrayList<BonusPresenter> getBonusRecebidos() {
        return bonusRecebidos;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getFaltas() {
        return faltas;
    }

    public void setFaltas(int faltas) {
        this.faltas = faltas;
    }

    public String getAdmissao() {
        return admissao;
    }

    public void setAdmissao(String admissao) {
        this.admissao = admissao;
    }

    
}
