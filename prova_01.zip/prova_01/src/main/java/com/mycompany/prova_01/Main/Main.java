package com.mycompany.prova_01.Main;

import com.mycompany.prova_01.Presenter.MenuPrincipal.MenuPrincipalPresenter;

public class Main {
    
    public static void main(String args[]) {
        MenuPrincipalPresenter menu = MenuPrincipalPresenter.getInstancia();
        menu.abrirView(true);
    }
    
}
