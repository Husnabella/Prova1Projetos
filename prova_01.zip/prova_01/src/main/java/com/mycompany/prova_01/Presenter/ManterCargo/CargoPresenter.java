package com.mycompany.prova_01.Presenter.ManterCargo;

public interface CargoPresenter {
    
    public double getSalarioBase();

    public String getCargo();
}
