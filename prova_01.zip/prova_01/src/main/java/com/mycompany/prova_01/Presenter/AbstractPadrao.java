package com.mycompany.prova_01.Presenter;

public abstract class AbstractPadrao {

    public abstract void initView();

    public abstract void abrirView(boolean b);
}
