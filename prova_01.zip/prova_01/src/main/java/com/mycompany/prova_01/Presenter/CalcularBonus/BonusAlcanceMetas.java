package com.mycompany.prova_01.Presenter.CalcularBonus;

public class BonusAlcanceMetas implements BonusPresenter {
    
    private String nomeBonus;

    public BonusAlcanceMetas() {
        this.nomeBonus = "Alcance de Metas";
    }

    @Override
    public String getNomeBonus() {
        return nomeBonus;
    }
    
    @Override
    public double calculaBonus() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
