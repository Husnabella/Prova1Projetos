package com.mycompany.prova_01.Presenter.MenuPrincipal;

import com.mycompany.prova_01.Presenter.ManterFuncionario.ManterFuncionarioPresenter;
import com.mycompany.prova_01.Presenter.AbstractPadrao;
import com.mycompany.prova_01.Presenter.ManterFuncionario.CriarFuncionario;
import com.mycompany.prova_01.Presenter.ManterFuncionario.LerFuncionario;
import com.mycompany.prova_01.View.MenuPrincipal.MenuPrincipalView;
import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;

public class MenuPrincipalPresenter extends AbstractPadrao {
    
    private static MenuPrincipalView view;
    
    private static MenuPrincipalPresenter instancia;
    
    private static ManterFuncionarioPresenter manterFuncionario;
    
    private static CriarFuncionario criarFuncionario;

    private static LerFuncionario lerFuncionario;
    
    private MenuPrincipalPresenter() {
        initView();
    }
    
    public static MenuPrincipalPresenter getInstancia() {
        if (instancia == null) {
            instancia = new MenuPrincipalPresenter() {};
        }
        return instancia;
    }

    @Override
    public void initView() {
        view = MenuPrincipalView.getInstancia();
        
        view.addActionListenerCadastrar((ActionEvent e) -> {
            opcaoCadastrar();
        });
        
        view.addActionListenerListar((ActionEvent e) -> {
            opcaoListar();
        });
    }
    
    @Override
    public void abrirView(boolean b) {
        view.setVisible(b);
    }
    
    public void addToDesktop(JInternalFrame frame) {
        view.addToDesktop(frame);
    }

    private void opcaoCadastrar() {
        criarFuncionario = CriarFuncionario.getInstancia();
        instancia.addToDesktop(criarFuncionario.getFrame());
        criarFuncionario.getFrame().setVisible(true);
    }

    private void opcaoListar() {
        lerFuncionario = LerFuncionario.getInstancia();
        instancia.addToDesktop(lerFuncionario.getFrame());
        lerFuncionario.getFrame().setVisible(true);
    }
}
