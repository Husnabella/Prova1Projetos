package com.mycompany.prova_01.View.MenuPrincipal;

import java.awt.event.ActionListener;
import javax.swing.JInternalFrame;

public class MenuPrincipalView extends javax.swing.JFrame {

    private static MenuPrincipalView instancia;

    private MenuPrincipalView() {
        initComponents();
    }

    public static MenuPrincipalView getInstancia() {
        if (instancia == null) {
            instancia = new MenuPrincipalView();
        }
        return instancia;
    }
    
    public void addToDesktop(JInternalFrame frame) {
        desktop.remove(frame);
        desktop.add(frame);
    }
    
    public void addActionListenerCadastrar(ActionListener e) {
        jMenuItemCadastrar.addActionListener(e);
    }
    
    public void addActionListenerListar(ActionListener e) {
        jMenuItemListar.addActionListener(e);
    }
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktop = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItemCadastrar = new javax.swing.JMenuItem();
        jMenuItemListar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout desktopLayout = new javax.swing.GroupLayout(desktop);
        desktop.setLayout(desktopLayout);
        desktopLayout.setHorizontalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 899, Short.MAX_VALUE)
        );
        desktopLayout.setVerticalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 563, Short.MAX_VALUE)
        );

        jMenu1.setText("Funcionário");

        jMenuItemCadastrar.setText("Cadastrar Funcionário");
        jMenu1.add(jMenuItemCadastrar);

        jMenuItemListar.setText("Listar Funcionários");
        jMenu1.add(jMenuItemListar);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktop;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemCadastrar;
    private javax.swing.JMenuItem jMenuItemListar;
    // End of variables declaration//GEN-END:variables
}
