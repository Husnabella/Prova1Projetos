package com.mycompany.prova_01.View.ManterFuncionario;

import com.mycompany.prova_01.Model.Funcionario;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class IfrmListarFuncionarioView extends javax.swing.JInternalFrame {

    private static IfrmListarFuncionarioView instancia;
    
    public IfrmListarFuncionarioView() {
        initComponents();
    }
    
    public static IfrmListarFuncionarioView getInstancia() {
        if (instancia == null) {
            instancia = new IfrmListarFuncionarioView();
        }
        return instancia;
    }
    
    public void adicionarActionListenerBonus(ActionListener e) {
        jButtonBonus.addActionListener(e);
    }
    
    public void adicionarActionListenerBuscar(ActionListener e) {
        jButtonBuscar.addActionListener(e);
    }
    
    public void adicionarActionListenerBotaoNovo(ActionListener e) {
        jButtonNovo.addActionListener(e);
    }
    
    public void adicionarActionListenerBotaoVisualizar(ActionListener e) {
        jButtonVisualizar.addActionListener(e);
    }
    
    public void adicionarActionListenerBotaoFechar(ActionListener e) {
        jButtonFechar.addActionListener(e);
    }
    
    public void addRowToJTable(ArrayList<Funcionario> lista) {       
    }
    
    public void preencheTabela(ArrayList<Funcionario> lista) {
        String[] columnNames = {"ID", "Nome", "Idade", "Cargo", "R$ Salário Base"};
        //jTable1 = new JTable(rowData, columnNames);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextFieldBusca = new javax.swing.JTextField();
        jButtonBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButtonFechar = new javax.swing.JButton();
        jButtonVisualizar = new javax.swing.JButton();
        jButtonBonus = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();

        setTitle("Buscar Funcionário");

        jLabel1.setText("Nome");

        jButtonBuscar.setText("Buscar");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Idade", "Cargo", "Salário Base (R$)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButtonFechar.setText("Fechar");

        jButtonVisualizar.setText("Visualizar");

        jButtonBonus.setText("Ver Bônus");

        jButtonNovo.setText("Novo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButtonFechar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonNovo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonBonus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonVisualizar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jTextFieldBusca)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonBuscar)))
                .addGap(34, 34, 34))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextFieldBusca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonFechar)
                    .addComponent(jButtonVisualizar)
                    .addComponent(jButtonBonus)
                    .addComponent(jButtonNovo))
                .addGap(118, 118, 118))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBonus;
    private javax.swing.JButton jButtonBuscar;
    private javax.swing.JButton jButtonFechar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonVisualizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextFieldBusca;
    // End of variables declaration//GEN-END:variables
}
