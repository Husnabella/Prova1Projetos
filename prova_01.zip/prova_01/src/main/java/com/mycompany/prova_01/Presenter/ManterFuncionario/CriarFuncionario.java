package com.mycompany.prova_01.Presenter.ManterFuncionario;

import com.mycompany.prova_01.Model.Funcionario;
import static com.mycompany.prova_01.Presenter.ManterFuncionario.ManterFuncionarioPresenter.view;
import com.mycompany.prova_01.Presenter.ManterCargo.CargoPresenter;

public class CriarFuncionario extends ManterFuncionarioPresenter {
    
    private CargoPresenter cargoPresenter;
    
    private Funcionario funcionario;
    
    private static CriarFuncionario instancia;
    
    private CriarFuncionario() {
        configuraCargo();
        configuraBonus();
        initView();
        setCamposEditableCriar(true);
        ajustarView(false, false, true, true);
    }
    
    public static CriarFuncionario getInstancia() {
        if (instancia == null) {
            instancia = new CriarFuncionario();
        }
        return instancia;
    }

    @Override
    public void botaoSalvarPressionado() {
        String cargo = view.getCampoCargo();
        funcionario = new Funcionario(0, "", 0, 0, cargo, "");
        funcionario.setIdFuncionario(geraId(listaFuncionarios()));
        funcionario.setNome(view.getCampoValores().get("nome"));
        funcionario.setCargo(cargo);
        funcionario.setSalario(Double.parseDouble(view.getCampoValores().get("salario")));
        funcionario.setIdade(Integer.parseInt(view.getCampoValores().get("idade")));
        funcionario.setAdmissao(view.getCampoValores().get("admissao"));
        
        listaFuncionarios().add(funcionario);
    }

    @Override
    public void botaoExcluirPressionado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void botaoEditarPressionado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void botaoFecharPressionado() {
        view.dispose();
    }
}
