package com.mycompany.prova_01.Presenter.ManterFuncionario;

import com.mycompany.prova_01.Model.Funcionario;
import com.mycompany.prova_01.Presenter.AbstractPadrao;
import com.mycompany.prova_01.Presenter.CalcularBonus.ManterBonusPresenter;
import com.mycompany.prova_01.Presenter.ManterCargo.ManterCargoPresenter;
import com.mycompany.prova_01.View.ManterFuncionario.IfrmManterFuncionarioView;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Map;
import javax.swing.JInternalFrame;

public abstract class  ManterFuncionarioPresenter extends AbstractPadrao {
    
    protected static IfrmManterFuncionarioView view;
    
    protected static EditarFuncionario editarFuncionario;
    
    protected static ManterCargoPresenter cargo;
    
    protected static ManterFuncionarioPresenter instancia;
    
    protected static ManterBonusPresenter bonus;

    public ManterFuncionarioPresenter() {
    }
    
    public static ManterFuncionarioPresenter getInstancia() {
        if (instancia == null) {
            instancia = new ManterFuncionarioPresenter() {
                @Override
                public void botaoSalvarPressionado() {
                }

                @Override
                public void botaoEditarPressionado() {
                }

                @Override
                public void botaoExcluirPressionado() {
                }

                @Override
                public void botaoFecharPressionado() {
                }
            };
        }
        return instancia;
    }
    
    @Override
    public void initView() {
        view = IfrmManterFuncionarioView.getInstancia();
        
        view.adicionarActionListenerBotaoSalvar((ActionEvent e) -> {
            botaoSalvarPressionado();
        });
        
        view.adicionarActionListenerBotaoEditar((ActionEvent e) -> {
            botaoEditarPressionado();
        });
        
        view.adicionarActionListenerBotaoExcluir((ActionEvent e) -> {
            botaoExcluirPressionado();
        });
        
        view.adicionarActionListenerBotaoFechar((ActionEvent e) -> {
            botaoFecharPressionado();
        });
    }
    
    public void configuraBonus() {
        bonus = ManterBonusPresenter.getInstancia();
        bonus.configuraBonus();
    }
    
    public void configuraCargo() {
        cargo = ManterCargoPresenter.getInstancia();
        cargo.configuraCargo();
    }
    
    public void calculaBonus(String nomeBonus) {
        bonus.calculaBonus(nomeBonus);
    }
    
    public ManterBonusPresenter novoBonus(String nomeBonus) {
        return bonus.novoBonus(nomeBonus);
    }
    
    public void setCampoValores(Map<String, String> valores) {
        view.setCampoValores(valores);
    }
    
    // HABILITAR CAMPOS
    
    public void setCamposEditableCriar(boolean b) {
        view.setCamposEditableCriar(b);
        view.setCamposEnabledCriar(b);
    }
    
    public void setCamposEditableEditar(boolean b) {
        view.setCamposEditableEditar(b);
        view.setCamposEnabledEditar(b);
    }
    
    public void setCamposEnabledVisualizar(boolean b) {
        view.setCamposEnabledVisualizar(b);
    }
    
    public int geraId(ArrayList<Funcionario> lista) {
        if (lista.isEmpty()) {
            return 1;
        } else {
            return (lista.size() + 1);
        }
    }
    
    public JInternalFrame getFrame() {
        view = IfrmManterFuncionarioView.getInstancia();
        return view;
    }
    
    public ArrayList<Funcionario> listaFuncionarios() {
        ArrayList<Funcionario> listaFuncionarios = new ArrayList<>();
        return listaFuncionarios;
    }
    
    // EDITANDO VIEW
    public void ajustarView(boolean editar, boolean excluir, boolean fechar, boolean salvar) {
        view.setBotaoEditarVisible(editar);
        view.setBotaoExcluirVisible(excluir);
        view.setBotaoFecharVisible(fechar);
        view.setBotaoSalvarVisible(salvar);
    }
    
    // BOTÕES
    
    public abstract void botaoSalvarPressionado();
    
    public abstract void botaoEditarPressionado();

    public abstract void botaoExcluirPressionado();

    public abstract void botaoFecharPressionado();
    
    // ABRIR VIEW

    @Override
    public void abrirView(boolean b) {
        view.setVisible(b);
    }

}
