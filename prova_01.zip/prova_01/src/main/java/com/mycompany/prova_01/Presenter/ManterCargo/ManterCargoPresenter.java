package com.mycompany.prova_01.Presenter.ManterCargo;

import com.mycompany.prova_01.Presenter.PopUpUtil;
import com.mycompany.prova_01.View.ManterFuncionario.IfrmManterFuncionarioView;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;

public class ManterCargoPresenter {
    
    protected static IfrmManterFuncionarioView view;
    
    protected static ManterCargoPresenter instancia;
    
    protected CargoPresenter cp;

    public ManterCargoPresenter() {
        
    }
    
    public static ManterCargoPresenter getInstancia() {
        if (instancia == null) {
            instancia = new ManterCargoPresenter();
        }
        return instancia;
    }
    
    public void configuraCargo() {
        view = IfrmManterFuncionarioView.getInstancia();
        addCargo();
        
        view.adicionarActionListenerBoxCargo((ActionEvent e) -> {
            opcaoBoxSelecionado(e);
        });
    }
    
    public void addSalario(String nome) {
        for (CargoPresenter cargo : listaCargo().values()) {
            if (nome.equals(cargo.getCargo()))
                view.setCampoSalario(cargo.getSalarioBase());
        }
    }
    
    public void addCargo() {
        view.preencheBoxCargo(listaNomeCargo(listaCargo()));
    }
    
    // CRIA CARGO
    
    public CargoPresenter novoAnalista() {
        cp = new Analista();
        return cp;
    }
    
    public CargoPresenter novoProgramador() {
        cp = new Programador();
        return cp;
    }
    
    public CargoPresenter novoGerente() {
        cp = new Gerente();
        return cp;
    }
    
    public Map<String, String> listaNomeCargo(Map<String, CargoPresenter> listaCargo) {
        HashMap<String, String> lista = new HashMap<>(); 
        for (String item : listaCargo.keySet()) {
            if(item.equals("analista"))
                lista.put("analista", (novoAnalista().getCargo()));
            if(item.equals("gerente"))
                lista.put("gerente", (novoGerente().getCargo()));
            if(item.equals("programador"))
                lista.put("programador", (novoProgramador().getCargo()));
        }
        
        return lista;
    }
    
    public Map<String, CargoPresenter> listaCargo() {
        HashMap<String, CargoPresenter> lista = new HashMap<>(); 
        lista.put("analista", novoAnalista());
        lista.put("gerente", novoGerente());
        lista.put("programador", novoProgramador());
        
        return lista;
    }

    private void opcaoBoxSelecionado(ActionEvent e) {
        String opcao = view.actionPerformedCargo(e);
        for (String item : listaNomeCargo(listaCargo()).values()) {
            if (opcao.equals(item)) {
                switch(item) {
                    case "Analista":
                        addSalario(item);
                        break;
                    case "Gerente":
                        addSalario(item);
                        break;
                    case "Programador":
                        addSalario(item);
                        break;
                    default:
                        PopUpUtil.mostrarPopUpErro(view, "Algo deu errado. Tente novamente!");
                }
            }
        } 
    }
}
