package com.mycompany.prova_01.Presenter.CalcularBonus;

import com.mycompany.prova_01.Model.Funcionario;
import com.mycompany.prova_01.Presenter.PopUpUtil;
import com.mycompany.prova_01.View.ManterFuncionario.IfrmManterFuncionarioView;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;

public class ManterBonusPresenter {
    
    protected static IfrmManterFuncionarioView view;
    
    protected static ManterBonusPresenter instancia;
    
    protected BonusPresenter bp;

    public ManterBonusPresenter() {

    }
    
    public static ManterBonusPresenter getInstancia() {
        if (instancia == null) {
            instancia = new ManterBonusPresenter();
        }
        return instancia;
    }
    
    public void configuraBonus() {
        view = IfrmManterFuncionarioView.getInstancia();
        addBonusBox();
        
        view.adicionarActionListenerBoxBonus((ActionEvent e) -> {
            opcaoBoxSelecionado(e);
        });
    }
    
    public void addBonusBox() {
        view.preencheBoxBonus(listaNomeBonus(listaBonus()));
    }
    
    public void calculaBonus(String nomeBonus) {
        double salarioTotal = 0;
        for (BonusPresenter bonus : listaBonus().values()) {
            if (nomeBonus.equals(bonus.getNomeBonus())) {
                salarioTotal = bonus.calculaBonus();
                view.setCampoSalario(salarioTotal);
            }
        }
    }
    
    public double calculaTotalBonus(Funcionario funcionario) {
        double totalBonus = 0;
        for (BonusPresenter bonus : funcionario.getBonusRecebidos()) {
            totalBonus += bonus.calculaBonus();
        }

        return totalBonus;
    }
    
    public int getCampoFaltas() {
        return view.getCampoFaltas();
    }
    
    public double getCampoSalario() {
        return view.getCampoSalario();
    }
    
    // CRIAR BONUS
    
    public ManterBonusPresenter novoBonus(String nomeBonus) {
        BonusPresenter novoBonus = null;
        for (BonusPresenter bonus : listaBonus().values()) {
            switch (nomeBonus) {
                case "Alcance de Metas" -> {
                    return (ManterBonusPresenter) novoAlcanceMetas();
                }
                case "Assiduidade" -> {
                    return (ManterBonusPresenter) novoAssiduidade();
                }
                case "Tempo-Serviço" -> {
                    return (ManterBonusPresenter) novoTempoServico();
                }
                default -> {
                }
            }
        }
        return (ManterBonusPresenter) novoBonus;
    }
    
    public BonusPresenter novoAlcanceMetas() {
        bp = new BonusAlcanceMetas();
        return bp;
    }
    
    public BonusPresenter novoAssiduidade() {
        bp = new BonusAssiduidade();
        return bp;
    }
    
    public BonusPresenter novoTempoServico() {
        bp = new BonusTempoServico();
        return bp;
    }
    
    public Map<String, String> listaNomeBonus(Map<String, BonusPresenter> listaCargo) {
        HashMap<String, String> lista = new HashMap<>(); 
        for (String item : listaCargo.keySet()) {
            if(item.equals("alcance-metas"))
                lista.put("alcance-metas", (novoAlcanceMetas().getNomeBonus()));
            if(item.equals("assiduidade"))
                lista.put("assiduidade", (novoAssiduidade().getNomeBonus()));
            if(item.equals("tempo-servico"))
                lista.put("tempo-servico", (novoTempoServico().getNomeBonus()));
        }
        
        return lista;
    }
    
    public Map<String, BonusPresenter> listaBonus() {
        HashMap<String, BonusPresenter> lista = new HashMap<>(); 
        lista.put("alcance-metas", novoAlcanceMetas());
        lista.put("assiduidade", novoAssiduidade());
        lista.put("tempo-servico", novoTempoServico());
        
        return lista;
    }

    private void opcaoBoxSelecionado(ActionEvent e) {
        String opcao = view.actionPerformedCargo(e);
        for (String item : listaNomeBonus(listaBonus()).values()) {
            if (opcao.equals(item)) {
                switch(item) {
                    case "Alcance de Metas":
                        //bp = new BonusAlcanceMetas();
                        calculaBonus(item);
                        break;
                    case "Assiduidade":
                        //bp = new BonusAssiduidade();
                        calculaBonus(item);
                        break;
                    case "Tempo-Serviço":
                        //bp = new BonusTempoServico();
                        calculaBonus(item);
                        break;
                    default:
                        PopUpUtil.mostrarPopUpErro(view, "Algo deu errado. Tente novamente!");
                }
            }
        } 
    }
}
