package com.mycompany.prova_01.Presenter.CalcularBonus;

public class BonusAssiduidade implements BonusPresenter {
    
    private String nomeBonus;

    public BonusAssiduidade() {
        this.nomeBonus = "Assiduidade";
    }

    @Override
    public String getNomeBonus() {
        return nomeBonus;
    }

    @Override
    public double calculaBonus() {
        double salarioTotal = 0, salarioBase = manterBonus.getCampoSalario();
        int faltas = manterBonus.getCampoFaltas();
        
        if (faltas == 0) {
            salarioTotal = (salarioBase * 0.1);
            return salarioTotal;
        } else if (faltas < 3) {
            salarioTotal = (salarioBase * 0.05);
            return salarioTotal;
        } else if (faltas >= 4) {
            salarioTotal = (salarioBase * 0.01);
            return salarioTotal;
        } else
            return 0;
    }
    
}
