package com.mycompany.prova_01.Model;

import java.util.ArrayList;

public class ListaFuncionario {
    
    private ArrayList<Funcionario> funcionarios;
    
}
