package com.mycompany.prova_01.Presenter.CalcularBonus;

import com.mycompany.prova_01.Model.Funcionario;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class BonusTempoServico implements BonusPresenter {
    
    private String nomeBonus;

    public BonusTempoServico() {
        this.nomeBonus = "Tempo-Serviço";
    }

    @Override
    public String getNomeBonus() {
        return nomeBonus;
    }
    
    @Override
    public double calculaBonus() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
