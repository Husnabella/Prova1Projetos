package com.mycompany.prova_01.Presenter.CalcularBonus;

public interface BonusPresenter {
    
    ManterBonusPresenter manterBonus = new ManterBonusPresenter();
    
    public double calculaBonus();
    
    public String getNomeBonus();
}
