package com.mycompany.prova_01.Presenter.ManterCargo;

public class Programador implements CargoPresenter {
    
    private final double salarioBase;
    
    private final String cargo;

    public Programador() {
        this.salarioBase = 3500.00;
        this.cargo = "Programador";
    }

    @Override
    public double getSalarioBase() {
        return salarioBase;
    }

    @Override
    public String getCargo() {
        return cargo;
    }
}
