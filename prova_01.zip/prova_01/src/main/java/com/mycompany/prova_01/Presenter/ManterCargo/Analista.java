package com.mycompany.prova_01.Presenter.ManterCargo;

public class Analista implements CargoPresenter {
    
    private final double salarioBase;
    
    private final String cargo;

    public Analista() {
        this.salarioBase = 3000.0;
        this.cargo = "Analista";
    }

    @Override
    public double getSalarioBase() {
        return salarioBase;
    }

    @Override
    public String getCargo() {
        return cargo;
    }
}
